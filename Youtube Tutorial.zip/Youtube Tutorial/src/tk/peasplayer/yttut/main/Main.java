package tk.peasplayer.yttut.main;

import org.bukkit.ChatColor;
import org.bukkit.plugin.java.JavaPlugin;

import tk.peasplayer.yttut.commands.Heal;

public class Main extends JavaPlugin{
	public static String prefix = ChatColor.GOLD + "YouTube" + ChatColor.DARK_GRAY + "�" + ChatColor.WHITE;
	
	@Override
	public void onEnable() {
		System.out.print("[YouTube] Das Plugin wurde erfolgreich geladen.");
		getCommand("heal").setExecutor(new Heal());
	}
	
}
