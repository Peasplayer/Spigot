package tk.peasplayer.youtube.main;

import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin{
	
	public void onEnable() {
		System.out.print("[YouTube] AbonniertPeasplayer.tk!");
	}
	
}
